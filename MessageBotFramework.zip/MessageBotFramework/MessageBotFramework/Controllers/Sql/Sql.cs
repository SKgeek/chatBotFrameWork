﻿using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;


namespace MessageBot.Controllers.Dialogs
{
  
    public partial class InitializeConversation : LuisDialog<object>
    {

        public async Task SaveToSql(LuisResult result, string userid , string reply)
        {
            /* 
            Save Intent , reply , date , UserId to Sql.
            where 
            Intent  =  result.Intents[0].Intent
            Query   =  result.Query 
            Reply   =  reply
            UserId  =  userId 
              
            */
        }






    }
}