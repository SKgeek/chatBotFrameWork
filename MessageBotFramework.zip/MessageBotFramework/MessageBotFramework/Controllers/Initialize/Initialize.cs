﻿using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;


namespace MessageBot.Controllers.Dialogs
{
   

    public partial class InitializeConversation : LuisDialog<object>
    {
        public string userDetail { get; set; }
        public  InitializeConversation(string userid)
        {
            userDetail = userid;
        }

    }
}