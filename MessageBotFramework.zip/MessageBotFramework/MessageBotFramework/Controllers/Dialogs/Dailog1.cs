﻿using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;


namespace MessageBot.Controllers.Dialogs
{
    [LuisModel("", "")]

    public partial class InitializeConversation : LuisDialog<object>
    {
      

        [LuisIntent("IntentName")]
        public async Task Dialog1Name(IDialogContext context, LuisResult result)
        {
            string reply = "Reply to Dialog 2";
            await  context.PostAsync(reply);

            
            context.Wait(MessageReceived);
            SaveToSql(result, userDetail, reply);
        }







    }
}